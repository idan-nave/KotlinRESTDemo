package com.idan.RestDemo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class RestDemoApplicationTests {

	@Test
	fun contextLoads() {
	}

}
